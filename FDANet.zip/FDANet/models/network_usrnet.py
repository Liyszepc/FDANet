import torch
import torch.nn as nn
import models.basicblock as B
import numpy as np
from utils import utils_image as util

import thop

import torch_dct as dct




def batched_index_select(values, indices):
    last_dim = values.shape[-1]
    return values.gather(1, indices[:, :, None].expand(-1, -1, last_dim))


def default_conv(in_channels, out_channels, kernel_size, stride=1, bias=True):
    return nn.Conv2d(
        in_channels, out_channels, kernel_size,
        padding=(kernel_size // 2), stride=stride, bias=bias)


class MeanShift(nn.Conv2d):
    def __init__(
            self, rgb_range,
            rgb_mean=(0.4488, 0.4371, 0.4040), rgb_std=(1.0, 1.0, 1.0), sign=-1):
        super(MeanShift, self).__init__(3, 3, kernel_size=1)
        std = torch.Tensor(rgb_std)
        self.weight.data = torch.eye(3).view(3, 3, 1, 1) / std.view(3, 1, 1, 1)
        self.bias.data = sign * rgb_range * torch.Tensor(rgb_mean) / std
        for p in self.parameters():
            p.requires_grad = False


def norm(x):
    return (1 - torch.exp(-x)) / (1 + torch.exp(-x))


def norm_(x):
    import numpy as np
    return (1 - np.exp(-x)) / (1 + np.exp(-x))





class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=1):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc1 = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=True)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=True)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        out = avg_out + max_out
        return x * self.sigmoid(out)

class SELayer(nn.Module):
    def __init__(self, channel, reduction=1):#16
        super(SELayer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
                nn.Linear(channel, channel // reduction),
                nn.ReLU(inplace=True),
                nn.Linear(channel // reduction, channel),
                nn.Sigmoid() #sigmoid
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x**2).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x *y#    x：48 1 96 96  y： 48 1 1 1


# Define a resnet block
class ResnetBlock(nn.Module):
    def __init__(self, dim, use_bias=True):
        super(ResnetBlock, self).__init__()
        self.conv_block = self.build_conv_block(dim, use_bias)
        self.ReLU = nn.ReLU(True)
        self.SE = SELayer(dim)  # ChannelAttention(dim) #
    def build_conv_block(self, dim, use_bias):
        conv_block = []

        conv_block += [nn.Conv2d(dim, dim, kernel_size=3, padding=1, bias=use_bias),
                       nn.BatchNorm2d(dim),
                       nn.ReLU(True)]

        conv_block += [nn.Conv2d(dim, dim, kernel_size=3, padding=1, bias=use_bias),
                       nn.BatchNorm2d(dim)]

        return nn.Sequential(*conv_block)

    def forward(self, x):
        out = x + self.SE(self.conv_block(x))  # out = x + self.SE(self.conv_block(x))
        # out = x + self.SE(self.conv_block(x))
        # out = x + self.SA(self.conv_block(x), self.conv_block(x))#out = x + self.SE(self.conv_block(x))
        return out


class sMLPBlock(nn.Module):
    def __init__(self, W, H, channels):
        super().__init__()
        assert W == H
        self.channels = channels
        self.activation = nn.GELU()
        self.BN = nn.BatchNorm2d(channels)
        self.proj_h = nn.Conv2d(H, H, (1, 1))
        self.proh_w = nn.Conv2d(W, W, (1, 1))
        self.fuse = nn.Conv2d(channels*3, channels, (1,1), (1,1), bias=False)

    def forward(self, x):
        x = self.activation(self.BN(x))
        x_h = self.proj_h(x.permute(0, 3, 1, 2)).permute(0, 2, 3, 1)
        x_w = self.proh_w(x.permute(0, 2, 1, 3)).permute(0, 2, 1, 3)
        x = self.fuse(torch.cat([x, x_h, x_w], dim=1))
        return x




class ResUNet(nn.Module):
    def __init__(self, in_nc=4, out_nc=3, nc=[64, 128, 256, 512], nb=2, act_mode='R', downsample_mode='strideconv', upsample_mode='convtranspose'):
        super(ResUNet, self).__init__()

        self.m_head = B.conv(in_nc, nc[0], bias=False, mode='C')

        # downsample
        if downsample_mode == 'avgpool':
            downsample_block = B.downsample_avgpool
        elif downsample_mode == 'maxpool':
            downsample_block = B.downsample_maxpool
        elif downsample_mode == 'strideconv':
            downsample_block = B.downsample_strideconv
        else:
            raise NotImplementedError('downsample mode [{:s}] is not found'.format(downsample_mode))

        self.m_down1 = B.sequential(*[B.ResBlock(nc[0], nc[0], bias=False, mode='C'+act_mode+'C') for _ in range(nb)], downsample_block(nc[0], nc[1], bias=False, mode='2'))
        self.m_down2 = B.sequential(*[B.ResBlock(nc[1], nc[1], bias=False, mode='C'+act_mode+'C') for _ in range(nb)], downsample_block(nc[1], nc[2], bias=False, mode='2'))
        self.m_down3 = B.sequential(*[B.ResBlock(nc[2], nc[2], bias=False, mode='C'+act_mode+'C') for _ in range(nb)], downsample_block(nc[2], nc[3], bias=False, mode='2'))

        self.m_body  = B.sequential(*[B.ResBlock(nc[3], nc[3], bias=False, mode='C'+act_mode+'C') for _ in range(nb)])

        # upsample
        if upsample_mode == 'upconv':
            upsample_block = B.upsample_upconv
        elif upsample_mode == 'pixelshuffle':
            upsample_block = B.upsample_pixelshuffle
        elif upsample_mode == 'convtranspose':
            upsample_block = B.upsample_convtranspose
        else:
            raise NotImplementedError('upsample mode [{:s}] is not found'.format(upsample_mode))

        self.m_up3 = B.sequential(upsample_block(nc[3], nc[2], bias=False, mode='2'), *[B.ResBlock(nc[2], nc[2], bias=False, mode='C'+act_mode+'C') for _ in range(nb)])
        self.m_up2 = B.sequential(upsample_block(nc[2], nc[1], bias=False, mode='2'), *[B.ResBlock(nc[1], nc[1], bias=False, mode='C'+act_mode+'C') for _ in range(nb)])
        self.m_up1 = B.sequential(upsample_block(nc[1], nc[0], bias=False, mode='2'), *[B.ResBlock(nc[0], nc[0], bias=False, mode='C'+act_mode+'C') for _ in range(nb)])

        self.m_tail = B.conv(nc[0], out_nc, bias=False, mode='C')

        self.SMLPr1 = sMLPBlock(W=96, H=96, channels=16)
        self.SMLPi1 = sMLPBlock(W=96, H=96, channels=16)
        self.SMLPr2 = sMLPBlock(W=48, H=48, channels=32)
        self.SMLPi2 = sMLPBlock(W=48, H=48, channels=32)
        self.SMLPr3 = sMLPBlock(W=24, H=24, channels=64)
        self.SMLPi3 = sMLPBlock(W=24, H=24, channels=64)
        self.SMLPr4 = sMLPBlock(W=12, H=12, channels=64)
        self.SMLPi4 = sMLPBlock(W=12, H=12, channels=64)

        self.SMLPdct = sMLPBlock(W=12, H=12, channels=64)
        # # DCT

        self.convdct1 = B.conv(64, 64, bias=True, mode='C')
        self.convdct2 = B.conv(64, 64, bias=True, mode='C')


    def forward(self, x):
        x_yuan = x.clone()

        h, w = x.size()[-2:]
        paddingBottom = int(np.ceil(h/8)*8-h)
        paddingRight = int(np.ceil(w/8)*8-w)
        x = nn.ReplicationPad2d((0, paddingRight, 0, paddingBottom))(x)

        x1 = self.m_head(x)
        x2 = self.m_down1(x1)
        x3 = self.m_down2(x2)
        x4 = self.m_down3(x3)

        # # GF

        # x1
        x11 = x1.clone()
        H, W = x11.shape[-2:]
        output_fft_new1 = torch.fft.fft2(x11, dim=(-2, -1))
        output_fft_new_2dim1 = torch.stack((output_fft_new1.real, output_fft_new1.imag), -1)
        output_fft_new_2dimr1 = output_fft_new_2dim1[:,:,:,:,0]
        output_fft_new_2dimi1 = output_fft_new_2dim1[:,:,:,:,1]
        output_fft_new_2dimr1 = self.SMLPr1(output_fft_new_2dimr1)
        output_fft_new_2dimi1 = self.SMLPi1(output_fft_new_2dimi1)
        output_fft_new_2dim1 = torch.stack((output_fft_new_2dimr1,output_fft_new_2dimi1),-1)
        Xest1 = torch.fft.irfft2(torch.complex(output_fft_new_2dim1[..., 0], output_fft_new_2dim1[..., 1]), s=(H, W))

        # x2
        x22 = x2.clone()
        H, W = x22.shape[-2:]
        output_fft_new2 = torch.fft.fft2(x22, dim=(-2, -1))
        output_fft_new_2dim2 = torch.stack((output_fft_new2.real, output_fft_new2.imag), -1)
        output_fft_new_2dimr2 = output_fft_new_2dim2[:,:,:,:,0]
        output_fft_new_2dimi2 = output_fft_new_2dim2[:,:,:,:,1]
        output_fft_new_2dimr2 = self.SMLPr2(output_fft_new_2dimr2)
        output_fft_new_2dimi2 = self.SMLPi2(output_fft_new_2dimi2)
        output_fft_new_2dim2 = torch.stack((output_fft_new_2dimr2,output_fft_new_2dimi2),-1)
        Xest2 = torch.fft.irfft2(torch.complex(output_fft_new_2dim2[..., 0], output_fft_new_2dim2[..., 1]), s=(H, W))
        # x3
        x33 = x3.clone()
        H, W = x33.shape[-2:]
        output_fft_new3 = torch.fft.fft2(x33, dim=(-2, -1))
        output_fft_new_2dim3 = torch.stack((output_fft_new3.real, output_fft_new3.imag), -1)
        output_fft_new_2dimr3 = output_fft_new_2dim3[:,:,:,:,0]
        output_fft_new_2dimi3 = output_fft_new_2dim3[:,:,:,:,1]
        output_fft_new_2dimr3 = self.SMLPr3(output_fft_new_2dimr3)
        output_fft_new_2dimi3 = self.SMLPi3(output_fft_new_2dimi3)
        output_fft_new_2dim3 = torch.stack((output_fft_new_2dimr3,output_fft_new_2dimi3),-1)
        Xest3 = torch.fft.irfft2(torch.complex(output_fft_new_2dim3[..., 0], output_fft_new_2dim3[..., 1]), s=(H, W))
        # x4
        x44 = x4.clone()
        H, W = x44.shape[-2:]
        output_fft_new4 = torch.fft.fft2(x44, dim=(-2, -1))
        output_fft_new_2dim4 = torch.stack((output_fft_new4.real, output_fft_new4.imag), -1)
        output_fft_new_2dimr4 = output_fft_new_2dim4[:,:,:,:,0]
        output_fft_new_2dimi4 = output_fft_new_2dim4[:,:,:,:,1]
        output_fft_new_2dimr4 = self.SMLPr4(output_fft_new_2dimr4)
        output_fft_new_2dimi4 = self.SMLPi4(output_fft_new_2dimi4)
        output_fft_new_2dim4 = torch.stack((output_fft_new_2dimr4,output_fft_new_2dimi4),-1)
        Xest4 = torch.fft.irfft2(torch.complex(output_fft_new_2dim4[..., 0], output_fft_new_2dim4[..., 1]), s=(H, W))

        x = self.m_body(x4)
        x = self.m_up3(x+x4+Xest4)
        x = self.m_up2(x+x3+Xest3)
        x = self.m_up1(x+x2+Xest2)
        x = self.m_tail(x+x1+Xest1)

        x = x[..., :h, :w]


        # # FA

        ycbcr_image = x_yuan
        num_batchsize = ycbcr_image.shape[0]
        size = ycbcr_image.shape[2]
        ycbcr_image = ycbcr_image.reshape(num_batchsize, 1, size // 8, 8, size // 8, 8).permute(0, 2, 4, 1, 3, 5)
        ycbcr_image = dct.dct_2d(ycbcr_image, norm='ortho')
        ycbcr_image = ycbcr_image.reshape(num_batchsize, size // 8, size // 8, -1).permute(0, 3, 1, 2)
        ycbcr_image = self.SMLPdct(ycbcr_image)
        ycbcr_image = self.convdct1(ycbcr_image)
        ycbcr_image = self.convdct2(ycbcr_image)
        ycbcr_image = ycbcr_image.reshape(num_batchsize,1,size,size)

        output_x = x + ycbcr_image


        return output_x




class USRNet(nn.Module):
    def __init__(self, n_iter=8, h_nc=64, in_nc=4, out_nc=3, nc=[64, 128, 256, 512], nb=2, act_mode='R', downsample_mode='strideconv', upsample_mode='convtranspose'):
        super(USRNet, self).__init__()

        self.p = ResUNet(in_nc=in_nc, out_nc=out_nc, nc=nc, nb=nb, act_mode=act_mode, downsample_mode=downsample_mode,
                         upsample_mode=upsample_mode)
        self.n = 3
    def forward(self, x, sf):

        x = nn.functional.interpolate(x, scale_factor=sf, mode='nearest')
        for i in range(self.n):
            x = self.p(x)

        return x
